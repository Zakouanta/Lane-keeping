function B = B1matrix(m,cf,lf,Iz)

B = [0;(2*cf)/m; 0; (2*lf*cf)/Iz];

end 




