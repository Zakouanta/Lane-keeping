function PIC = PIC(t, tau, a)
    PIC = 1/(tau*t + 1)*a;
end