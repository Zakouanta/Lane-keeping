function B = Bmatrix(m,cf,Iz)
B = [0;
     2*cf/m;
     0;
     2*cf/Iz];
end 