function B1_1 = B1_1matrix(m,cf,lf,Iz)

B1_1 = [0;(2*cf)/m; 0; (2*lf*cf)/Iz];

end 




