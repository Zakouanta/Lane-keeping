clc 
clear all 
close all 

%% Parameters

m = 2164; %kg 
Iz = 4373 ; % Kg.m^2
velocity = 50; % m/s
Vx = (velocity * 1000)/3600; % m/s
amplitude = pi/6; % amplitude of the input 
frequency = 0.5; 
lf = 1.3384; % m 
lr = 1.6456; % m 
cf = 1.0745*10^5;
cr = 1.9032*10^5;
R = 5 ; % Rdius of the circular desired path 
 



%% Computation 

% We just need the initial condition condition to be close enough to zero
% so we define a random numbers with equal prob between -1 and 1 
% x_0 = 2*rand(4,1)-1;
x_0 = zeros(4,1);



% Compute matrices 
A=Amatrix(m,Vx,cf,cr,lf,lr,Iz);
B = Bmatrix(m,cf,Iz);
C = eye(4);
D = zeros(4,1);
u = deltaf(amplitude,frequency);



%Compute matrices for the road aligned model 

A1 = A1matrix(m,Vx,cf,cr,lf,lr,Iz);
B1_1 = B1_1matrix(m,cf,lf,Iz);
B_d = B_dmatrix(m,cf,cr,Iz,Vx,lf,lr);
B1 = [B1_1 B_d];
C1 = eye(4);
D1 = zeros(4,2);
%Initial states 
x2_0 = zeros (4,1);
% psi_des 
psidot_des = Vx/R;





%% Plot 

