function [G, Kp, Ki] = PI_tune(tau, ratio)
     numerator = [1 ratio];
     denominator = [tau 1 0 0]; 
     G = tf (numerator,denominator); % Transfer function definition
     Kp= 0.7; %initial value of Kp
     Ki= Kp * ratio; %initial value of Ki
end 