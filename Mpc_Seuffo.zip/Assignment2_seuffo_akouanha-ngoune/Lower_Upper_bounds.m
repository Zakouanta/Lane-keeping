function [lb, ub] = Lower_Upper_bounds(max_e1, max_e2, max_delta_u, N)
    % Define lower and upper bounds for states and control inputs
    xmin = [0; -1; 0; -1]; 
    xmax = [max_e1; 1; max_e2; 1];
    umin = -max_delta_u;
    umax = max_delta_u;
    
    % Concatenate bounds for control inputs (repeated N+1 times)
    lb_control = [umin; umin];
    ub_control = [umax; umax];
    lb_control = repmat(lb_control, N+1, 1);
    ub_control = repmat(ub_control, N+1, 1);
    
    % Concatenate bounds for states (repeated N times)
    lb_state = repmat(xmin, N+1, 1);
    ub_state = repmat(xmax, N+1, 1);
    
    % Concatenate lower and upper bounds for all variables
    lb = [lb_control; lb_state];
    ub = [ub_control; ub_state];
end
