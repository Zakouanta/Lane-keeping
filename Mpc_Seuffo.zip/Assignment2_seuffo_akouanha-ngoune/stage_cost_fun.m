function cost = stage_cost_fun(u_OL_tilde, Q, R, P_f, xmeasure, N, lf, Ad, Bd, delta_step)
    % Reshape optimal input sequence
    u_OL_tilde = reshape(u_OL_tilde, [], 2);
    u_OL = u_OL_tilde(1:N, :);
    
    % Update the closed-loop system
    x_temp = xmeasure;
    for k = 1:N
        delta = u_OL(k, 1);
        a = u_OL(k, 2);
        x_temp = x_temp + delta * [cos(x_temp(3)); sin(x_temp(3)); tan(delta) / lf; 0] * delta_step + a * [cos(x_temp(3)); sin(x_temp(3)); 0; 1] * delta_step;
    end
    
    % Calculate stage costs
    stage_costs = sum(x_temp(1:4:end)' * Q * x_temp(1:4:end) + x_temp(2:4:end)' * Q * x_temp(2:4:end) + x_temp(3:4:end)' * Q * x_temp(3:4:end) + x_temp(4:4:end)' * Q * x_temp(4:4:end) + ...
        u_OL(:, 1)' * R * u_OL(:, 1) + u_OL(:, 2)' * R * u_OL(:, 2));
    
    % Calculate terminal cost
    x_term = x_temp + Ad * x_temp + Bd * u_OL(end, :)';
    terminal_cost = x_term' * P_f * x_term;
    
    % Total cost
    cost = stage_costs + terminal_cost;
end