function xdot_kinematic = xdot_kinematic(t,u,x, beta, lf, lr)
     xdot_kinematic = [u(1)*cos(x(3)+beta); u(1)*sin(x(3)+beta); (u(1)*cos(beta)/(lf + lr))*(tan(u(2))-tan(u(3)))];        
end 