clc
clear all 
close all 


%% Load numerical paramters
run('num_parameters.m');
%% Initialise parameters for kinematic model 

X = 0; % global X coordinate 
Y = 0; % global Y coordinate 
psi = 0; % Orientation  
delta_f = 0; % front steering angle 
delta_r = 0; % rear steering angle 
beta = 0 ; % slip angle 
control_input = @(t) deg2rad(30 * sin(2 * pi * frequency * t)); % sinusoidal control input 
x = [X; Y; psi]; % state vector 
u = [Vx, delta_f, delta_r]; % control vector 
%Init for plot 
t = 0;
course = 0;
global_position_plot = [];
u_plot = [u(1)'; u(2)'; u(3)'];
beta_plot = [beta'];
course_plot = [course'];
%% Recalling functions 
xdot_kinematic = @xdot_kinematic;
%% Compute over time 
while t<=t_end
    u = [Vx, control_input(t), 0];
    beta =atan( (lf * tan(u(3)) + lr*tan(u(2))) / (lf+lr) );% slip ange computed 
    %Compute the solution of the differential equation 
    [tsol, xsol] = ode45(@(t,x) xdot_kinematic(t,u,x,beta,lf,lr), [t t+dt], x(:,end));
    x = [x xsol(end,:)'];
    %Update variables to plot 
    global_position_plot = x(1:2, :); 
    u_plot = [u_plot u']; % Update steering angle 
    vehicle_heading = x(3, :); % Vehicle heading 
    beta_plot = [beta_plot beta']; % Update slip angle 
    course = beta + x(3);
    course_plot = [course_plot course'];   
    t = t+dt;
end 


%% PLOT 
t_plot = 0:dt:t_end+dt ;
%  Transfer sim datas into vars to send at the plotter
position_def = global_position_plot;    % Global position
vehicle_heading_def = vehicle_heading;      % Vehicle heading
slip_angle_def = beta_plot;              % Slip angle
steering_angle_def = u_plot(2, :);    % Steering angle
course_angle_def = course_plot;    % Course angle
%  Plot
plotVehicleData(t_plot, x, position_def, vehicle_heading_def, slip_angle_def, course_angle_def, steering_angle_def, []);

