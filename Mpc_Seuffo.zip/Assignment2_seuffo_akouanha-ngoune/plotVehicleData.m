function plotVehicleData(t, x, position, vehicleHeading, slipAngle, courseAngle, steeringAngle, desiredPosition)
    % Plot vehicle data in the global frame
    figure;

    % Plot desired path if available
    subplot(3, 2, [1, 2]);
    if any(desiredPosition(:)) % Check if any element in desiredPosition is non-zero
        plot(desiredPosition(1, :), desiredPosition(2, :), 'g-', 'LineWidth', 1.5);
        hold on;
    end

    % Plot vehicle position
    hold on;
    plot(position(1, :), position(2, :), 'r-', 'LineWidth', 1.5);
    title('Vehicle position in the global frame');
    xlabel('Position X (m)');
    ylabel('Position Y (m)');
    grid on;
    % Add legend if desired path is available
    if any(desiredPosition(:)) % Check if any element in desiredPosition is non-zero
        legend('Desired path', 'Position in the global frame');
    end

    index_p = 3;

    % Plot vehicle heading if available
    if any(vehicleHeading(:)) % Check if any element in vehicleHeading is non-zero
        subplot(3, 2, index_p);
        plot(t, rad2deg(vehicleHeading(1, :)), 'm-', 'LineWidth', 1.5);
        title('Vehicle heading');
        xlabel('Time (s)');
        ylabel('Vehicle heading (°)');
        grid on;
        index_p = index_p + 1;
    end

    % Plot slip angle if available
    if any(slipAngle(:)) % Check if any element in slipAngle is non-zero
        subplot(3, 2, index_p);
        plot(t, rad2deg(slipAngle(1, :)), 'b-', 'LineWidth', 1.5);
        title('Slip angle');
        xlabel('Time (s)');
        ylabel('Slip angle (°)');
        grid on;
        index_p = index_p + 1;
    end

    % Plot course angle if available
    if any(courseAngle(:)) % Check if any element in courseAngle is non-zero
        subplot(3, 2, index_p);
        plot(t, rad2deg(courseAngle(1, :)), 'c-', 'LineWidth', 1.5);
        title('Course angle');
        xlabel('Time (s)');
        ylabel('Course angle (°)');
        grid on;
        index_p = index_p + 1;
    end

    % Plot steering angle if available
    if any(steeringAngle(:)) % Check if any element in steeringAngle is non-zero
        subplot(3, 2, index_p);
        plot(t, rad2deg(steeringAngle(1, :)), 'k-', 'LineWidth', 1.5);
        title('Steering angle');
        xlabel('Time (s)');
        ylabel('Steering angle (°)');
        grid on;
        index_p = index_p + 1;
    end

    % Show better position (and desired position)
    figure;

    % Plot desired path if available
    if any(desiredPosition(:)) % Check if any element in desiredPosition is non-zero
        plot(desiredPosition(1, :), desiredPosition(2, :), 'g-', 'LineWidth', 1.5);
        hold on;
    end

    % Plot vehicle position
    hold on;
    plot(position(1, :), position(2, :), 'r-', 'LineWidth', 1.5);
    title('Vehicle position in the global frame');
    xlabel('Position X (m)');
    ylabel('Position Y (m)');
    grid on;

    % Add legend if desired path is available
    if any(desiredPosition(:)) % Check if any element in desiredPosition is non-zero
        legend('Desired path', 'Position in the global frame');
    end
end
