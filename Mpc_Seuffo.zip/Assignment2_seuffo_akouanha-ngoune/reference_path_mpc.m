function [x, y, psidot_des_mpc, psi_des_mpc] = reference_path_mpc(Vx, R, L_straight)
    % Define distance vector along the path
    s_total = L_straight + pi*R; % Total distance along the path
    s = linspace(0, s_total, 1000); % Divide the total distance into intervals

    % Calculate vehicle speed at each point along the path
    %Vx = linspace(V_min, V_max, length(s))/3.6; % Varying speed over space in m/s 

    % Define reference path functions
    % Straight segment
    s1 = @(s) min(s, L_straight); % Straight segment length

    % Circular arc segment
    s_arc = s - L_straight; % Distance traveled along the circular arc
    theta = s_arc / R; % Corresponding angle

    % Compute x and y coordinates along the path
    x = zeros(size(s));
    y = zeros(size(s));
    psidot_des_mpc = zeros(size(s));

    for i = 1:length(s)
        if s(i) <= L_straight
            x(i) = s1(s(i));
            y(i) = 0;
            psidot_des_mpc(i) = 0;
        else
            x(i) = L_straight + R * sin(theta(i));
            y(i) = R - R * cos(theta(i));
            
        end
    end

    psidot_des_mpc(i) = Vx/R;

    % Integrate psidot_des_mpc to get psi_des_mpc
    psi_des_mpc = cumtrapz(s, psidot_des_mpc);
end
