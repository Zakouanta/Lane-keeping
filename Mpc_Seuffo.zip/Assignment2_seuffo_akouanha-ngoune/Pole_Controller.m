clc                             % Clear command window
close all                       % Close all figures
clear all                       % Clear all workspace variables
%% Parameters 
run ('num_parameters.m');        % Run script to set numerical parameters
run ('parameter_init.m');        % Run script to initialize parameters
Vdes = Vx;                       % Set desired velocity as the initial velocity
%% Pole placement
xdotPP = @xdotPP;                % Define function handle for state-space system
%% PI Controller
PI = @PI;                        % Define function handle for Proportional-Integral controller
PIC = @PIC;                      % Define function handle for Proportional-Integral with Clamping controller
%% Recalling function

% Compute state matrix A
A = Amatrix(m,Vx,cf,cr,lf,lr,Iz); 

% Compute input matrix B1
B = B1matrix(m,cf,lf,Iz); 

% Compute disturbance input matrix B_d
B_d = B_dmatrix(m,cf,cr,Iz,Vx,lf,lr); 

% Identity matrix for output
C = eye(4);                      

% Zeros matrix for direct feedthrough
D = zeros(4,2); 

% Gain matrix 
[omega_n, S] = specifications(deltap,deviation,zeta);
Kpp = PolePlacement(deltap,omega_n,A,B); % Compute pole placement controller gains
%% CONTROLLER 
% Check the reachability 
R = [B A*B (A^2)*B (A^3)*B];      % Controllability matrix
rank_R = rank(R);                 % Rank of controllability matrix
if rank_R == length(A)
    disp('FULLY REACHABLE')
else 
    disp('NOT FULLY REACHABLE')
end

%% Controller simulation 
boolean_param = true;            % Boolean parameter for controller update
K_update = K_update_vel_interval(velocity_interval, boolean_param); % Get controller gains
while t <= 2*t_end
    % PI Controller

    % Compute velocity error integral
    integrator = Velocity_integrator(t,Vx,Vdes); 

    % Update reference velocity
    longitudinal_ref = [longitudinal_ref integrator];

    % Simulate PI controller  
    [tsol, x_pi] = ode45(@(t,longitudinal_ref) PI(t,Vx,Vdes,Kp,Ki), [t t+dt], longitudinal_ref(:,end)); 

    % Update longitudinal reference
    longitudinal_des= [longitudinal_des x_pi(end,:)]; 
    
    % Simulate PIC controller
    [tsol, x_pic] = ode45(@(t,longitudinal_des) PIC(t, tau, longitudinal_des), [t t+dt], longitudinal_des(:,end));

    % Update longitudinal position
    longitudinal_pos= [longitudinal_pos x_pic(end,:)]; 
  
    V_update = Vx;                 % Update velocity
    if t ~= 0
        V_update = V_update + longitudinal_pos(end)/t; % Update velocity based on position
    end
    % Choose the appropriate control gain K based on the variation of Vx
    if (V_update * 3.6) >= 30 && (V_update * 3.6) < 40 - e_acc
        index = 1;
    elseif (V_update * 3.6) >= 40 && (V_update * 3.6) < 50 - e_acc
        index = 2;
    elseif (V_update * 3.6) >= 50 && (V_update * 3.6) < 60 - e_acc
        index = 3;
    elseif (V_update * 3.6) >= 60 && (V_update * 3.6) < 70 - e_acc
        index = 4;
    elseif (V_update * 3.6) >= 70 && (V_update * 3.6) < 80 - e_acc
        index = 5;
    elseif (V_update * 3.6) >= 80 && (V_update * 3.6) < 90 - e_acc
        index = 6;
    elseif (V_update * 3.6) >= 90 && (V_update * 3.6) < 100 - e_acc
        index = 7;
    elseif (V_update * 3.6) >= 100 && (V_update * 3.6) < 110 - e_acc
        index = 8;
    elseif (V_update * 3.6) >= 110 && (V_update * 3.6) < 120 - e_acc
        index = 9;
    else
        index = 10;
    end

    % Update state matrix A based on current velocity
    A1 = Amatrix(m,V_update,cf,cr,lf,lr,Iz);  

    % Update input matrix B1 based on current velocity
    B1 = B1matrix(m,cf,lf,Iz);                  

    % Update disturbance input matrix B_d based on current velocity
    B_d1 = B_dmatrix(m,cf,cr,Iz,V_update,lf,lr); 

    % Choose controller gains based on speed
    K = K_update{index};                   

    % Compute desired path parameters
    [w, psi_des_t, xdes_t, ydes_t] = Desired_path(V_update, r, t);

    % Define the feedforward term for zero steady-state error
    delta_ff = feedforward(m, V_update, lf, lr, cf, cr, r, K);

    % Simulate system dynamics
    [tsol, xsolpp] = ode45(@(t,x) xdotPP(A1,B1,x,B_d1,w,K,delta_ff), [t t+dt], xpp(:,end)); 
    
    % Simulate system dynamics
    xpp = [xpp xsolpp(end,:)'];               
    % UPDATES 
    % Update heading 
    heading = xpp(3, end) + psi_des_t;         % Update heading
    heading_plot = [heading_plot xpp(3, end)']; % Store heading data
    % Update global position 
    X1 = xdes_t - xpp(1,end)*sin(heading);    % Update global X position
    Y1 = ydes_t + xpp(1,end)*cos(heading);    % Update global Y position
    pos_des = [pos_des [xdes_t ydes_t]'];      % Store desired position data
    position_global = [position_global [X1 Y1 heading]']; % Store global position data
    % Update slip angle
    vehicle_slip = (1/V_update)*xpp(2, end) - xpp(3, end); % Compute slip angle
    slip = [slip vehicle_slip'];               % Store slip angle data
    % Update course 
    course_t = heading + vehicle_slip;         % Update course angle
    course_angle = [course_angle course_t'];   % Store course angle data
    % Update steering 
    u = (-K*xpp(:,end)) + delta_ff;            % Update steering angle
    steering_angle = [steering_angle u'];      % Store steering angle data
    % Expected heading error
    e2 = (-(lr/r)) + ((lf/(2* cr * (lf + lr))) * ((m*V_update^2)/r)); % Compute expected heading error
    heading_error = [heading_error e2'];       % Store heading error data 
    t = t + dt;                               % Increment time
    if t >= 10
        r = 1000;   % Radius for a circular path after 10 seconds
    else
        r = inf;   % Infinite radius for a straight line for the first 10 seconds
    end    
end
%% Plot the result
% Re-fetch the time simulation
t_plot = 0:dt:2*t_end;
% Transfer simulation data into variables for plotting
position_def = position_global;        % Global position
vehicle_heading_def = heading_plot;         % Vehicle heading
slip_angle_def = slip;              % Slip angle
course_angle_def = course_angle;            % Course angle
steering_angle_def = steering_angle(1, :);    % Steering angle
% Plot the results
plotVehicleData(t_plot, xpp, position_def, vehicle_heading_def, slip_angle_def, course_angle_def, steering_angle_def, pos_des);
