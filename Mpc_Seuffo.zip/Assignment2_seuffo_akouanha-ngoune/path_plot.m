% Parameters
clc
clear all
close all
R1 = 999999999999999999999999;
l1 = 200;
R2 = 1000;
l2 = R2 * pi / 2;
s=0;
x_ref_plot =[];
y_ref_plot = [];
% Call the function to get x_ref, y_ref, psi_ref
while s < l2 
[x_ref, y_ref , psi_ref, curvature] = Reference_path(R1, R2, s,l1);
x_ref_plot = fliplr([x_ref_plot x_ref]);
y_ref_plot = fliplr([y_ref_plot y_ref]);
s = s+1;
end 
% Plot the reference path
figure;
plot(x_ref_plot, y_ref_plot, 'o', 'MarkerSize', 2, 'MarkerFaceColor', 'r');
title('Reference Path');
xlabel('X_reference');
ylabel('Y_reference');
grid on;  