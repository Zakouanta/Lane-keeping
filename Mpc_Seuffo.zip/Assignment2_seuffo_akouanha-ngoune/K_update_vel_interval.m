function design_K = K_update_vel_interval(velocity_interval, boolean_param)
% loading Parameters 
run ('num_parameters.m');
d_Vx=10; %Velocity step 
V_min= velocity_interval(1);
V_max= velocity_interval(2);
%Recalling matrices for the min velocity 
A_min = Amatrix(mass,V_min,cf,cr,lf,lr,Iz);
B = B1matrix(mass,cf,lf,Iz);
B_d_min = B_dmatrix(mass,cf,cr,Iz,V_min,lf,lr);
%Recalling the matrices for the maximun value of Vx
A_max = Amatrix(mass,V_max,cf,cr,lf,lr,Iz);
B_d_min = B_dmatrix(mass,cf,cr,Iz,V_max,lf,lr);

[omega_n, S] = specifications(deltap,deviation,zeta);
if boolean_param == true 
    K_min = PolePlacement(deltap,omega_n,A_min,B);
    K_max = PolePlacement(deltap,omega_n,A_max,B);
else 
    [Q_min, K_min, S, CLP_min] = LQR(A_min, B);
    [Q_max, K_max, S, CLP_max] = LQR(A_max, B);
end
%Initialiase and aray to store the values of K and set it to the the min if
%we get to the last one 
design_K = {};
design_K{end+1}= K_min;

for Vx = velocity_interval(1)+10:d_Vx:velocity_interval(2)-1

    A = Amatrix(mass,Vx,cf,cr,lf,lr,Iz);
    B = B1matrix(mass,cf,lf,Iz);
    B_d = B_dmatrix(mass,cf,cr,Iz,Vx,lf,lr);

    if boolean_param == true 
        K_update = PolePlacement(deltap,omega_n,A,B);
    else 
       [Q, K_update, S, CLP] = LQR(A, B);

    end 
    design_K{end+1} = K_update;
 end

design_K{end+1} = K_max;

end 