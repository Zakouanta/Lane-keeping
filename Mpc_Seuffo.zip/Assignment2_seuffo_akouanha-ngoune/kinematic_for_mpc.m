function z_dot = kinematic_for_mpc(z,u,A_mpc,B_mpc)
     z_dot = A_mpc*z * B_mpc*u; 
end 